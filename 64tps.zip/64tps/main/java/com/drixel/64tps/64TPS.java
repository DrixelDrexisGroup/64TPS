package com.drixel.64tps;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class 64TPS implements ModInitializer {
    public static final String MOD_ID = "64tps";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("64TPS mod initialized. Increasing TPS detection to 64.");
    }
}