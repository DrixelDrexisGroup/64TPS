package com.drixel.64tps;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;

public class tick {
    private static long[] tickTimes = new long[64];
    private static int tickCount = 0;
    
    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(tick::onServerTick);
    }
    
    private static void onServerTick(MinecraftServer server) {
        if (server.isRunning()) {
            long currentTime = System.nanoTime();
            tickTimes[tickCount % tickTimes.length] = currentTime;
            tickCount++;
        }
    }
    
    public static double getTPS() {
        if (tickCount < tickTimes.length) {
            return 20.0; // Default TPS until we have enough data
        }
        
        long now = System.nanoTime();
        long oldestTickTime = tickTimes[tickCount % tickTimes.length];
        long timeElapsed = now - oldestTickTime;
        
        // Calculate TPS based on 64 ticks instead of 20
        return Math.min(1000000000.0 / ((timeElapsed) / 64.0), 64.0);
    }
    
    public static long[] getTickTimes() {
        return tickTimes.clone();
    }
    
    public static int getTickCount() {
        return tickCount;
    }
}