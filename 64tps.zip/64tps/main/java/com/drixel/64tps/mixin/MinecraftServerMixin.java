package com.drixel.64tps.mixin;

import com.drixel.64tps.tick;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftServer.class)
public class MinecraftServerMixin {
    @Inject(method = "getTickTime", at = @At("HEAD"), cancellable = true)
    private void onGetTickTime(CallbackInfoReturnable<Long> cir) {
        // 替换原有的tick时间计算
        long[] tickTimes = tick.getTickTimes();
        int tickCount = tick.getTickCount();
        
        if (tickCount < tickTimes.length) {
            return; // 使用默认实现直到有足够数据
        }
        
        long now = System.nanoTime();
        long oldestTickTime = tickTimes[tickCount % tickTimes.length];
        long timeElapsed = now - oldestTickTime;
        
        // 返回基于64tps计算的平均tick时间
        cir.setReturnValue(timeElapsed / 64);
    }
}