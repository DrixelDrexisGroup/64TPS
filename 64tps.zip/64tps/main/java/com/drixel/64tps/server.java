package com.drixel.64tps;

import net.fabricmc.api.DedicatedServerModInitializer;

public class server implements DedicatedServerModInitializer {
    @Override
    public void onInitializeServer() {
        tick.initialize();
        System.out.println("64TPS server mod initialized");
    }
}